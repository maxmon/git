#!/bin/bash

git push -u origin master
